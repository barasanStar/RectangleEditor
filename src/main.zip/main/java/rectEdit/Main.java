package rectEdit;

import rectEdit.app.RectEditorLauncher;

public class Main {
	public static void main(String[] args) {
		RectEditorLauncher.launch();
	}
}