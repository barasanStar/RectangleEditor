package rectEdit.handler;

@FunctionalInterface
public interface ActionHandler {
	void handle();
}
