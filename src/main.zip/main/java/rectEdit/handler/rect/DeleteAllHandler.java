package rectEdit.handler.rect;

import rectEdit.handler.ActionHandler;
import rectEdit.model.RectEditorModel;

public class DeleteAllHandler implements ActionHandler {
	private final RectEditorModel model;

	public DeleteAllHandler(RectEditorModel model) {
		this.model = model;
	}

	@Override
	public void handle() {
		model.pushSnapshot(); // Undo対応
		model.clearAllRects(); // モデル変更通知を含む
	}
}
